import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, StandardScaler

url = r"\Titanic-Dataset.csv"
data = pd.read_csv(url)

print("Original Data Shape:", data.shape)
print("Missing Values Before Processing:\n", data.isnull().sum())

data['Age'] = data['Age'].fillna(data['Age'].mean())
data['Embarked'] = data['Embarked'].fillna(data['Embarked'].mode()[0])

data = data.drop(columns=['Cabin', 'Name', 'Ticket'])

Q1 = data['Fare'].quantile(0.25)
Q3 = data['Fare'].quantile(0.75)
IQR = Q3 - Q1
lower = Q1 - 1.5 * IQR
upper = Q3 + 1.5 * IQR
data = data[(data['Fare'] >= lower) & (data['Fare'] <= upper)]

encoder = LabelEncoder()
data['Sex'] = encoder.fit_transform(data['Sex'])
data['Embarked'] = encoder.fit_transform(data['Embarked'])

scaler = StandardScaler()
scaled_features = scaler.fit_transform(data[['Age', 'Fare', 'SibSp', 'Parch']])
scaled_df = pd.DataFrame(scaled_features, columns=['Age', 'Fare', 'SibSp', 'Parch'])

data[['Age', 'Fare', 'SibSp', 'Parch']] = scaled_df

print("\nData After Preprocessing:\n", data.head())
print("\nMissing Values After Processing:\n", data.isnull().sum())
print("\nFinal Data Shape:", data.shape)