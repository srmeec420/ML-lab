import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.mixture import GaussianMixture
from sklearn.metrics import silhouette_score
import matplotlib.pyplot as plt

url = r"\winequality-white.csv"
data = pd.read_csv(url, sep=";")

print("Dataset shape:", data.shape)
print("Columns:", data.columns)

X = data.drop('quality', axis=1)
y = data['quality']

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

n_clusters = 6
gmm = GaussianMixture(n_components=n_clusters, covariance_type='full', random_state=42)
gmm.fit(X_scaled)

labels = gmm.predict(X_scaled)
data['Cluster'] = labels

sil_score = silhouette_score(X_scaled, labels)
print("\nSilhouette Score:", sil_score)

plt.figure(figsize=(8, 6))
plt.scatter(X_scaled[:, 0], X_scaled[:, 1], c=labels, cmap='viridis', s=50)
plt.title('Wine Clustering using GMM')
plt.xlabel(data.columns[0])
plt.ylabel(data.columns[1])
plt.colorbar(label='Cluster')
plt.show()